import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { HabitsPage } from './pages/HabitsPage';
import { StatsPage } from './pages/StatsPage';

/**
 * Props for the App component.  Currently empty as no props are passed.
 */
interface AppProps { }

/**
 * Root component of the application. Sets up routing and renders the main layout.
 * @param {AppProps} props - The props passed to the component.
 * @returns {JSX.Element} - The rendered component.
 */
const App: React.FC<AppProps> = () => {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<HabitsPage />} />
          <Route path="/stats" element={<StatsPage />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export { App };