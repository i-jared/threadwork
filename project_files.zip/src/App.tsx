import React, { useState } from 'react';
import HabitList from './components/HabitList';
import PageHeader from './components/PageHeader';
import ClearCompletedButton from './components/ClearCompletedButton';

interface Habit {
  id: string;
  name: string;
  completed: boolean;
}

const App: React.FC = () => {
  const [habits, setHabits] = useState<Habit[]>([]);

  const addHabit = () => {
    const newHabit: Habit = {
      id: crypto.randomUUID(),
      name: '',
      completed: false,
    };
    setHabits([...habits, newHabit]);
  };

  const updateHabit = (id: string, updatedHabit: Partial<Habit>) => {
    setHabits(
      habits.map((habit) =>
        habit.id === id ? { ...habit, ...updatedHabit } : habit
      )
    );
  };

  const deleteHabit = (id: string) => {
    setHabits(habits.filter((habit) => habit.id !== id));
  };

  const clearCompletedHabits = () => {
    setHabits(habits.filter((habit) => !habit.completed));
  };

  return (
    <div className="container mx-auto p-4">
      <PageHeader onAddHabit={addHabit} />

      <HabitList
        habits={habits}
        onUpdateHabit={updateHabit}
        onDeleteHabit={deleteHabit}
      />

      {habits.some((habit) => habit.completed) && (
        <ClearCompletedButton onClearCompleted={clearCompletedHabits} />
      )}
    </div>
  );
};

export default App;