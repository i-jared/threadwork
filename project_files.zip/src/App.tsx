import React, { useState, useCallback } from 'react';
import { Habit } from './types/Habit';
import { HabitList } from './components/HabitList';
import { HabitForm } from './components/HabitForm';
import { Layout } from './layout/Layout';

interface AppProps {}

/**
 * The main application component that renders the entire habit tracking app.
 * @param {} props - The component props.
 * @returns JSX.Element - The rendered component.
 */
const App: React.FC<AppProps> = () => {
  const initialHabits: Habit[] = [
    { id: '1', name: 'Drink Water', frequency: 'daily', completed: false },
    { id: '2', name: 'Exercise', frequency: 'weekly', completed: true },
  ];

  const [habits, setHabits] = useState<Habit[]>(initialHabits);

  /**
   * Adds a new habit to the list.
   * @param habit - The habit to add.
   */
  const addHabit = useCallback((habit: Habit) => {
    setHabits((prevHabits) => [...prevHabits, habit]);
  }, []);

  /**
   * Updates an existing habit.
   * @param updatedHabit - The updated habit.
   */
  const updateHabit = useCallback((updatedHabit: Habit) => {
    setHabits((prevHabits) =>
      prevHabits.map((habit) =>
        habit.id === updatedHabit.id ? updatedHabit : habit
      )
    );
  }, []);

  /**
   * Deletes a habit from the list.
   * @param id - The ID of the habit to delete.
   */
  const deleteHabit = useCallback((id: string) => {
    setHabits((prevHabits) => prevHabits.filter((habit) => habit.id !== id));
  }, []);

  return (
    <Layout>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">Habit Tracker</h1>
        <HabitForm addHabit={addHabit} />
        <HabitList
          habits={habits}
          updateHabit={updateHabit}
          deleteHabit={deleteHabit}
        />
      </div>
    </Layout>
  );
};

export { App };