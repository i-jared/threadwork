import React, { useState, useCallback } from 'react';
import { Habit } from './types/Habit';

/**
 * Props for the AddHabitForm component.
 */
export interface AddHabitFormProps {
  /**
   * Function to call when a new habit is added.
   * @param habit - The new habit to add.
   */
  onAddHabit: (habit: Habit) => void;
}

/**
 * AddHabitForm component allows the user to add a new habit.
 */
export const AddHabitForm: React.FC<AddHabitFormProps> = React.memo(({ onAddHabit }) => {
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');

  /**
   * Handles changes to the habit name input.
   */
  const handleNameChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    setName(event.target.value);
  }, []);

  /**
   * Handles changes to the habit description input.
   */
  const handleDescriptionChange = useCallback((event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setDescription(event.target.value);
  }, []);

  /**
   * Handles the form submission, adding the new habit.
   */
  const handleSubmit = useCallback((event: React.FormEvent) => {
    event.preventDefault();

    const newHabit: Habit = {
      id: Date.now().toString(),
      name: name,
      description: description,
      completed: false,
    };

    onAddHabit(newHabit);
    setName('');
    setDescription('');
  }, [name, description, onAddHabit]);

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">
          Habit Name:
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="name"
          type="text"
          placeholder="Enter habit name"
          value={name}
          onChange={handleNameChange}
          required
        />
      </div>
      <div className="mb-6">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
          Description:
        </label>
        <textarea
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="description"
          placeholder="Enter habit description"
          value={description}
          onChange={handleDescriptionChange}
          rows={3}
        />
      </div>
      <div className="flex items-center justify-between">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          type="submit"
        >
          Add Habit
        </button>
      </div>
    </form>
  );
});