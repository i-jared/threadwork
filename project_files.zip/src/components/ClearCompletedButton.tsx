import React from 'react';

interface ClearCompletedButtonProps {
  onClearCompleted: () => void;
  disabled: boolean;
}

const ClearCompletedButton: React.FC<ClearCompletedButtonProps> = ({ onClearCompleted, disabled }) => {
  return (
    <button
      onClick={onClearCompleted}
      disabled={disabled}
      className={`px-4 py-2 rounded-md text-sm font-medium ${
        disabled
          ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
          : 'bg-red-500 hover:bg-red-700 text-white'
      }`}
    >
      Clear Completed
    </button>
  );
};

export default ClearCompletedButton;