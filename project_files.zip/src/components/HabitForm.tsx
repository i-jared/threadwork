import React, { useState, useCallback } from 'react';
import { Habit } from './types/Habit';

export interface HabitFormProps {
  onAddHabit: (habit: Habit) => void;
}

/**
 * HabitForm Component: A form to add new habits.
 * @param {HabitFormProps} props - The component props.
 * @returns {JSX.Element} The HabitForm component.
 */
export const HabitForm = React.memo(({ onAddHabit }: HabitFormProps): JSX.Element => {
  const [name, setName] = useState<string>('');
  const [description, setDescription] = useState<string>('');

  /**
   * Handles the form submission.
   * @param {React.FormEvent} event - The form event.
   */
  const handleSubmit = useCallback((event: React.FormEvent) => {
    event.preventDefault();

    const newHabit: Habit = {
      id: Date.now().toString(),
      name: name,
      description: description,
      completed: false,
    };

    onAddHabit(newHabit);
    setName('');
    setDescription('');
  }, [name, description, onAddHabit]);

  /**
   * Handles name input change.
   * @param {React.ChangeEvent<HTMLInputElement>} event - The input change event.
   */
  const handleNameChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    setName(event.target.value);
  }, []);

  /**
   * Handles description input change.
   * @param {React.ChangeEvent<HTMLTextAreaElement>} event - The textarea change event.
   */
  const handleDescriptionChange = useCallback((event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setDescription(event.target.value);
  }, []);

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="name">
          Habit Name:
        </label>
        <input
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="name"
          type="text"
          placeholder="Enter habit name"
          value={name}
          onChange={handleNameChange}
          required
        />
      </div>
      <div className="mb-6">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
          Description:
        </label>
        <textarea
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="description"
          placeholder="Enter habit description"
          value={description}
          onChange={handleDescriptionChange}
          rows={3}
        />
      </div>
      <div className="flex items-center justify-between">
        <button
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          type="submit"
        >
          Add Habit
        </button>
      </div>
    </form>
  );
});