import React, { useState } from 'react';
import { FaEdit, FaTrash } from 'react-icons/fa';

interface HabitItemProps {
  id: string;
  name: string;
  completed: boolean;
  onUpdate: (id: string, newName: string, newCompleted: boolean) => void;
  onDelete: (id: string) => void;
}

const HabitItem: React.FC<HabitItemProps> = ({ id, name, completed, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [newName, setNewName] = useState(name);
  const [isChecked, setIsChecked] = useState(completed);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewName(e.target.value);
  };

  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
    onUpdate(id, newName, !isChecked);
  };

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleSaveClick = () => {
    onUpdate(id, newName, isChecked);
    setIsEditing(false);
  };

  const handleDeleteClick = () => {
    onDelete(id);
  };

  return (
    <div className="flex items-center justify-between p-2 border-b border-gray-200">
      <div className="flex items-center">
        <input
          type="checkbox"
          id={`habit-${id}`}
          checked={isChecked}
          onChange={handleCheckboxChange}
          className="mr-2 h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
        />
        {isEditing ? (
          <input
            type="text"
            value={newName}
            onChange={handleNameChange}
            className="w-48 p-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-indigo-200"
          />
        ) : (
          <label htmlFor={`habit-${id}`} className={`text-lg ${isChecked ? 'line-through text-gray-500' : 'text-gray-800'}`}>
            {name}
          </label>
        )}
      </div>

      <div>
        {isEditing ? (
          <button
            onClick={handleSaveClick}
            className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mr-2"
          >
            Save
          </button>
        ) : (
          <button
            onClick={handleEditClick}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2"
          >
            <FaEdit />
          </button>
        )}
        <button
          onClick={handleDeleteClick}
          className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
        >
          <FaTrash />
        </button>
      </div>
    </div>
  );
};

export default HabitItem;