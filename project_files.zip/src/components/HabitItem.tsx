import React from 'react';
import { Habit } from './types/Habit';

export interface HabitItemProps {
  habit: Habit;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

/**
 * Represents a single habit item in the list.
 */
const HabitItem = React.memo(({ habit, onToggle, onDelete }: HabitItemProps) => {
  /**
   * Handles the toggle event for the habit.
   */
  const handleToggle = React.useCallback(() => {
    onToggle(habit.id);
  }, [habit.id, onToggle]);

  /**
   * Handles the delete event for the habit.
   */
  const handleDelete = React.useCallback(() => {
    onDelete(habit.id);
  }, [habit.id, onDelete]);

  return (
    <div className="flex items-center justify-between p-4 mb-2 bg-white rounded-lg shadow">
      <div>
        <input
          type="checkbox"
          id={`habit-${habit.id}`}
          checked={habit.completed}
          onChange={handleToggle}
          className="mr-2 leading-tight"
        />
        <label htmlFor={`habit-${habit.id}`} className={`text-gray-700 text-sm ${habit.completed ? 'line-through' : ''}`}>
          {habit.name}
        </label>
      </div>
      <div>
        <button onClick={handleDelete} className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
          Delete
        </button>
      </div>
    </div>
  );
});

export { HabitItem };
export type { HabitItemProps };