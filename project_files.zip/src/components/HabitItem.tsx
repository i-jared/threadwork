import React, { useCallback } from 'react';
import { Habit } from './types/Habit';

export interface HabitItemProps {
  habit: Habit;
  onToggle: (id: string) => void;
}

/**
 * HabitItem Component: Displays a single habit item with its name and a completion toggle.
 * @param {HabitItemProps} props - The props for the HabitItem component.
 * @returns {JSX.Element} - The rendered HabitItem component.
 */
export const HabitItem = React.memo(({ habit, onToggle }: HabitItemProps): JSX.Element => {
  /**
   * Handles the toggle event for the habit completion status.
   */
  const handleToggle = useCallback(() => {
    onToggle(habit.id);
  }, [habit.id, onToggle]);

  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow hover:bg-gray-100 transition-colors duration-200">
      <span className={`text-lg ${habit.completed ? 'line-through text-gray-500' : 'text-gray-800'}`}>
        {habit.name}
      </span>
      <button
        onClick={handleToggle}
        className={`rounded-full h-6 w-6 flex items-center justify-center focus:outline-none ${
          habit.completed
            ? 'bg-green-500 hover:bg-green-700 text-white'
            : 'bg-gray-300 hover:bg-gray-400 text-gray-700'
        } transition-colors duration-200`}
        aria-label={habit.completed ? 'Mark as incomplete' : 'Mark as complete'}
      >
        {habit.completed ? '✓' : ''}
      </button>
    </div>
  );
});