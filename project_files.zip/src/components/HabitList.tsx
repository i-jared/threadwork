import React, { useMemo } from 'react';
import { Habit } from '../types/Habit';
import { HabitItem } from './HabitItem';

export interface HabitListProps {
  habits: Habit[];
  onDelete: (id: string) => void;
  onToggle: (id: string) => void;
}

/**
 * HabitList Component: Displays a list of habits.
 *
 * @param {HabitListProps} props - The component props.
 * @returns {JSX.Element} The rendered HabitList component.
 */
export const HabitList: React.FC<HabitListProps> = React.memo(({ habits, onDelete, onToggle }) => {
  /**
   * Memoized habits array to prevent unnecessary re-renders.
   */
  const memoizedHabits = useMemo(() => habits, [habits]);

  return (
    <div className="space-y-4">
      {memoizedHabits.map((habit) => (
        <HabitItem
          key={habit.id}
          habit={habit}
          onDelete={onDelete}
          onToggle={onToggle}
        />
      ))}
    </div>
  );
});