import React from 'react';
import { useState } from 'react';
import { Habit } from './types';
import { FaEdit, FaTrash } from 'react-icons/fa';

interface HabitListProps {
  habits: Habit[];
  onHabitToggle: (id: string) => void;
  onHabitNameChange: (id: string, newName: string) => void;
  onHabitDelete: (id: string) => void;
}

const HabitList: React.FC<HabitListProps> = ({
  habits,
  onHabitToggle,
  onHabitNameChange,
  onHabitDelete,
}) => {
  const [editingHabitId, setEditingHabitId] = useState<string | null>(null);

  const handleEditClick = (id: string) => {
    setEditingHabitId(id);
  };

  const handleNameChange = (id: string, event: React.ChangeEvent<HTMLInputElement>) => {
    onHabitNameChange(id, event.target.value);
  };

  const handleBlur = () => {
    setEditingHabitId(null);
  };


  return (
    <div className="space-y-2">
      {habits.map((habit) => (
        <div key={habit.id} className="flex items-center justify-between p-2 bg-white rounded shadow">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={habit.completed}
              onChange={() => onHabitToggle(habit.id)}
              className="form-checkbox h-5 w-5 text-green-500 focus:ring-green-500 rounded"
            />
            {editingHabitId === habit.id ? (
              <input
                type="text"
                value={habit.name}
                onChange={(e) => handleNameChange(habit.id, e)}
                onBlur={handleBlur}
                className="form-input flex-grow rounded border-gray-300 focus:ring-blue-500 focus:border-blue-500"
                autoFocus
              />
            ) : (
              <span className={`text-gray-800 ${habit.completed ? 'line-through' : ''}`}>
                {habit.name}
              </span>
            )}
          </label>
          <div className="space-x-2">
            {editingHabitId !== habit.id && (
              <button
                onClick={() => handleEditClick(habit.id)}
                className="text-blue-500 hover:text-blue-700 focus:outline-none"
              >
                <FaEdit />
              </button>
            )}
            <button
              onClick={() => onHabitDelete(habit.id)}
              className="text-red-500 hover:text-red-700 focus:outline-none"
            >
              <FaTrash />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default HabitList;