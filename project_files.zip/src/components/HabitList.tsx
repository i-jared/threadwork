import React from 'react';
import { Habit } from '../types/Habit';
import { HabitItem } from './HabitItem';

export interface HabitListProps {
  habits: Habit[];
  onDelete: (id: string) => void;
  onToggle: (id: string) => void;
}

/**
 * HabitList Component: Displays a list of habits.
 * Each habit is rendered using the HabitItem component.
 */
export const HabitList: React.FC<HabitListProps> = React.memo(({ habits, onDelete, onToggle }) => {
  /**
   * Renders a single habit item.
   * @param habit The habit to render.
   * @returns A HabitItem component.
   */
  const renderHabitItem = (habit: Habit) => (
    <HabitItem
      key={habit.id}
      habit={habit}
      onDelete={onDelete}
      onToggle={onToggle}
    />
  );

  return (
    <div className="space-y-4">
      {habits.map(renderHabitItem)}
    </div>
  );
});