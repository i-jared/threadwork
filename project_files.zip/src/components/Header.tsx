import React, { useCallback, useMemo } from 'react';
import { Link } from 'react-router-dom';

/**
 * HeaderProps interface defines the props for the Header component.
 * @param title - The title of the application.
 * @param navLinks - An array of navigation links. Each link has a label and a path.
 */
export interface HeaderProps {
  title: string;
  navLinks: { label: string; path: string }[];
}

/**
 * Header component renders the header of the application with navigation links.
 * It is memoized to prevent unnecessary re-renders.
 * @param props - The props for the Header component.
 * @returns The header element.
 */
const HeaderComponent = ({ title, navLinks }: HeaderProps) => {

  /**
   * Memoized navigation links to prevent re-renders.
   */
  const memoizedNavLinks = useMemo(() => navLinks, [navLinks]);

  /**
   * Generates the navigation links.
   */
  const renderNavLinks = useCallback(() => {
    return memoizedNavLinks.map((link) => (
      <li key={link.label} className="mr-6">
        <Link to={link.path} className="text-blue-500 hover:text-blue-800">{link.label}</Link>
      </li>
    ));
  }, [memoizedNavLinks]);

  return (
    <header className="bg-gray-100 p-4 shadow-md">
      <div className="container mx-auto flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold">{title}</Link>
        <nav>
          <ul className="flex">
            {renderNavLinks()}
          </ul>
        </nav>
      </div>
    </header>
  );
};

/**
 * Memoized Header component to prevent unnecessary re-renders.
 */
export const Header = React.memo(HeaderComponent);