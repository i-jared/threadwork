import React, { ReactNode } from 'react';
import { Header } from './Header';

/**
 * Props for the Layout component.
 */
export interface LayoutProps {
  children: ReactNode;
}

/**
 * Provides the main layout structure with a header and a content area.
 * @param {LayoutProps} props - The props for the Layout component.
 * @returns {JSX.Element} The Layout component.
 */
export const Layout: React.FC<LayoutProps> = React.memo(({ children }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow bg-gray-100 py-4 px-6">
        {children}
      </main>
      <footer className="bg-gray-200 text-center py-2">
        &copy; {new Date().getFullYear()} My Company
      </footer>
    </div>
  );
});