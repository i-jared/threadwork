import { PlusIcon } from "@heroicons/react/24/solid";

interface PageHeaderProps {
  onAddHabit: () => void;
}

const PageHeader: React.FC<PageHeaderProps> = ({ onAddHabit }) => {
  return (
    <div className="bg-gray-100 py-4 px-6 flex items-center justify-between shadow-md">
      <h1 className="text-2xl font-semibold text-gray-800">Habit Tracker</h1>
      <button
        onClick={onAddHabit}
        className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center"
      >
        <PlusIcon className="h-5 w-5 mr-2" />
        Add Habit
      </button>
    </div>
  );
};

export default PageHeader;