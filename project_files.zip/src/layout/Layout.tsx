import React, { PropsWithChildren } from 'react';
import './Layout.css';

/**
 * Interface for Layout component props.
 */
export interface LayoutProps extends PropsWithChildren<{}> {
  /**
   * Optional class name for the layout.
   */
  className?: string;
}

/**
 * Layout component to wrap the whole app.
 * @param {LayoutProps} props - The props for the Layout component.
 * @returns {JSX.Element} The Layout component.
 */
const Layout: React.FC<LayoutProps> = React.memo(({ children, className = '' }) => {
  return (
    <div className={`app-layout min-h-screen bg-gray-100 ${className}`}>
      <header className="bg-white shadow">
        <div className="mx-auto max-w-7xl py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900">
            Your App Header
          </h1>
        </div>
      </header>
      <main>
        <div className="mx-auto max-w-7xl py-6 sm:px-6 lg:px-8">
          {/* Your content */}
          <div className="px-4 py-6 sm:px-0">
            {children}
          </div>
          {/* /End replace */}
        </div>
      </main>
    </div>
  );
});

export { Layout };
export type { LayoutProps };