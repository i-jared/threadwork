import React, { useState, useCallback } from 'react';
import { Habit } from '../types/Habit';
import { HabitList } from '../components/HabitList';
import { AddHabitForm } from '../components/AddHabitForm';

export interface HabitsPageProps {
  initialHabits?: Habit[];
}

/**
 * HabitsPage Component: Displays a list of habits and allows the user to add new habits.
 *
 * @param {HabitsPageProps} props - The props for the HabitsPage component.
 * @returns {JSX.Element} The HabitsPage component.
 */
export const HabitsPage: React.FC<HabitsPageProps> = React.memo(({ initialHabits = [] }: HabitsPageProps) => {
  const [habits, setHabits] = useState<Habit[]>(initialHabits);

  /**
   * Adds a new habit to the list of habits.
   *
   * @param {Habit} newHabit - The habit to add.
   */
  const addHabit = useCallback((newHabit: Habit) => {
    setHabits((prevHabits) => [...prevHabits, newHabit]);
  }, []);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Habit Tracker</h1>
      <AddHabitForm onAddHabit={addHabit} />
      <HabitList habits={habits} />
    </div>
  );
});