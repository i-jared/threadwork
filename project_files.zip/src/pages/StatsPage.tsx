import React from 'react';

/**
 * Props for the StatsPage component.
 */
export interface StatsPageProps {
  /**
   * The total number of habits tracked.
   */
  totalHabits: number;
  /**
   * The number of completed habits.
   */
  completedHabits: number;
  /**
   * The current streak of completed habits.
   */
  currentStreak: number;
  /**
   * The longest streak of completed habits.
   */
  longestStreak: number;
}

/**
 * StatsPage component to display user statistics related to habits.
 */
export const StatsPage: React.FC<StatsPageProps> = React.memo(({
  totalHabits,
  completedHabits,
  currentStreak,
  longestStreak,
}) => {
  /**
   * Percentage of completed habits.
   */
  const completionPercentage = React.useMemo(() => {
    if (totalHabits === 0) {
      return 0;
    }
    return Math.round((completedHabits / totalHabits) * 100);
  }, [completedHabits, totalHabits]);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Your Habit Stats</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Total Habits</h2>
          <p className="text-3xl font-bold">{totalHabits}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Completed Habits</h2>
          <p className="text-3xl font-bold">{completedHabits}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Current Streak</h2>
          <p className="text-3xl font-bold">{currentStreak}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Longest Streak</h2>
          <p className="text-3xl font-bold">{longestStreak}</p>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <h2 className="text-lg font-semibold mb-2">Completion Percentage</h2>
          <p className="text-3xl font-bold">{completionPercentage}%</p>
        </div>
      </div>
    </div>
  );
});