```typescript
// types/Habit.ts

/**
 * Habit type definition.
 */
export type Habit = {
  id: string;
  name: string;
  description: string;
  frequency: string; // e.g., "Daily", "Weekly", "Monthly"
  goal: number; // Target number of times to complete the habit
  completed: number; // Number of times the habit has been completed
  startDate: Date;
  endDate?: Date;
  color: string; // Hex color code for UI representation
};
```