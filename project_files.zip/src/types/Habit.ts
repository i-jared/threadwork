/**
 * Habit type definition.
 */
export type Habit = {
  id: string;
  name: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
  userId: string;
  frequency: HabitFrequency;
  timeOfDay?: HabitTimeOfDay;
  goalQuantity?: number;
  goalUnit?: string;
};

export type HabitFrequency = 'daily' | 'weekly' | 'monthly';
export type HabitTimeOfDay = 'morning' | 'afternoon' | 'evening';