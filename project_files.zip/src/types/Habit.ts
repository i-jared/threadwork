/**
 * @typedef Habit
 * @property {string} id - The unique identifier of the habit.
 * @property {string} name - The name of the habit.
 * @property {string} description - A description of the habit.
 * @property {number} frequency - The frequency of the habit (e.g., days per week).
 */
export type Habit = {
  id: string;
  name: string;
  description: string;
  frequency: number;
};